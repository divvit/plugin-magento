<?php

	class Divvit_Divvit_Model_Order extends Mage_Core_Model_Abstract{
		protected function _construct()
		{
			$this->_init('divvit_divvit/order');
		}
	}
